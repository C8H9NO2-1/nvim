require"battery".setup({})
