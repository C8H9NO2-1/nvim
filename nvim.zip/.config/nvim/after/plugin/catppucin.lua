local catppucin = require("catppuccin")

catppucin.setup({
    integrations = {
        beacon = true,
        noice = true,
        gitgutter = true,
    }
})
