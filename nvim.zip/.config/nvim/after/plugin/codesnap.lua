require("codesnap").setup({
    has_breadcrumbs = true, -- This is to show the path of the file
    -- show_workspace = true, -- This shows the name of the workspace
    -- has_line_number = true,
    bg_theme = "default", -- See the doc for the other themes
    watermark = "@C8H9NO2",
    mac_window_bar = false,
})

vim.keymap.set("v", "<leader>cc", "<cmd>CodeSnap<CR>", {
    desc = "Save selected code snapshot into clipboard"
})
