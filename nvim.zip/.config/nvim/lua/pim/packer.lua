-- This file can be loaded by calling `lua require('plugins')` from your init.vim

-- Only required if you have packer configured as `opt`
vim.cmd [[packadd packer.nvim]]

return require('packer').startup(function(use)
  -- Packer can manage itself
  use 'wbthomason/packer.nvim'

  use {
      'nvim-telescope/telescope.nvim', tag = '0.1.6',
      -- or                            , branch = '0.1.x',
      requires = { {'nvim-lua/plenary.nvim'} }
  }

  use('sainnhe/gruvbox-material')
  -- use('f4z3r/gruvbox-material.nvim')

  use('nvim-treesitter/nvim-treesitter', {run = ':TSUpdate'})
  use('theprimeagen/harpoon')
  use('mbbill/undotree')
  use('tpope/vim-fugitive')
  use {
      'VonHeikemen/lsp-zero.nvim',
      branch = 'v3.x',
      requires = {
          {'williamboman/mason.nvim'},
          {'williamboman/mason-lspconfig.nvim'},
          {'neovim/nvim-lspconfig'},
          {'hrsh7th/nvim-cmp'},
          {'hrsh7th/cmp-nvim-lsp'},
          {'L3MON4D3/LuaSnip'},
      }
  }

  use('beardedfoo/vim-colemak') --? This is for my keyboard
  use('jiangmiao/auto-pairs') --? This for brackets and parentheses
  use('mhinz/vim-startify') --? This is a start menu
  use('tpope/vim-surround') --? This is to help change quickly the surrounding parentheses
  use('airblade/vim-gitgutter') --? This shows git diffs in the files
  use('rust-lang/rust.vim') --? This explains itself
  -- use('907th/vim-auto-save') --? This auto save the files
  use('Djancyp/better-comments.nvim') --? This is for those beautifull colored comments
  use('m4xshen/hardtime.nvim') --? This is to force me to learn better vim motions
  use('folke/noice.nvim') --? This is to get some nice ui (for commands and messages)
  --? Those three next are dependecies for the previous one
  use('MunifTanjim/nui.nvim')
  use('nvim-lua/plenary.nvim')
  use('rcarriga/nvim-notify')
  use('stevearc/oil.nvim') --? This is a better file explorer
  use('nvim-tree/nvim-web-devicons') --? This is for the previous one
  use('HiPhish/rainbow-delimiters.nvim') --? This is to have matching parentheses
  use('L3MON4D3/LuaSnip') --? This is to be able to make some snippets
  use('lervag/vimtex') --? This is to write some LaTeX
  use({
      "iamcco/markdown-preview.nvim",
      run = function() vim.fn["mkdp#util#install"]() end,
  }) --? This is to preview markdown
  use('ThePrimeagen/vim-be-good') --? This is to train myself
  use {'mistricky/codesnap.nvim', run = 'make'} --? This is to take "screenshots of the code"
  -- use('freddiehaddad/feline.nvim')
  use { "catppuccin/nvim", as = "catppuccin" }
  use {"akinsho/toggleterm.nvim", tag = '*', config = function()
      require("toggleterm").setup()
  end}
  use('lewis6991/gitsigns.nvim')
  use {
      'nvim-lualine/lualine.nvim',
      requires = { 'nvim-tree/nvim-web-devicons', opt = true }
  }
  use { 'justinhj/battery.nvim', requires = {{'nvim-tree/nvim-web-devicons'}, {'nvim-lua/plenary.nvim'}}}
  use{'archibate/lualine-time', requires = { 'kyazdani42/nvim-web-devicons', opt = true }}
  use('danilamihailov/beacon.nvim')
end)
