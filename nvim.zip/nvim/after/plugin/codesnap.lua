require("codesnap").setup({
    -- has_breadcrumbs = true, -- This is to show the path of the file
    -- show_workspace = true, -- This shows the name of the workspace
    -- has_line_number = true,
    bg_theme = "default",
    -- bg_theme = "bamboo",
    -- bg_theme = "sea",
    -- bg_theme = "peach",
    -- bg_theme = "grape",
    -- bg_theme = "dusk",
    -- bg_theme = "summer",
    -- bg_color = "#535c68",
    watermark = "",
    -- watermark = "@C8H9NO2",
    bg_padding = 0,
    mac_window_bar = false,
    save_path = "~/Downloads/",
})

vim.keymap.set("x", "<leader>cc", "<cmd>CodeSnap<CR>", {
    desc = "Save selected code snapshot into clipboard"
})
