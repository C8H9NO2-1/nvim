local ls = require('luasnip')
local s = ls.snippet
local sn = ls.snippet_node
local t = ls.text_node
local i = ls.insert_node
local f = ls.function_node
local c = ls.choice_node
local d = ls.dynamic_node
local r = ls.restore_node
local extras = require('luasnip.extras')
local rep = extras.rep

vim.keymap.set({"i"}, "<C-E>", function() ls.expand() end, {silent = true})
vim.keymap.set({"i", "s"}, "<C-I>", function() ls.jump( 1) end, {silent = true})
vim.keymap.set({"i", "s"}, "<C-N>", function() ls.jump(-1) end, {silent = true})

ls.add_snippets("tex", {
    s("ff", {
        t("\\frac{"), i(1), t("}{"), i(2), t("}"), i(0)
    }),
    s("env", {
        t("\\begin{"), i(1), t("}"),
        t({ "", "\\end{" }), rep(1), t("}")
    })
})
