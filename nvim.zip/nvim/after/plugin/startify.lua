local g = vim.g

g.startify_lists = {
  { type = 'dir', header = { "   Current Directory "..vim.fn.getcwd()..":" } },
  { type = 'bookmarks', header = { '   Bookmarks' } }
}

g.startify_bookmarks = {
  { c = '~/.config/nvim/'},
  { b = '~/.bash_profile'},
  { z = '~/.zshrc'},
  { t = '~/.tmux.conf' },
  { p = '~/Documents/ESISAR/NE302/ProjetHTTP/Serveur/' },
  { n = vim.fn.getcwd() },
  { g = '~/.gitconfig' }
}

