local g = vim.g

vim.keymap.set("n", "<leader>lv", "<cmd>VimtexView<CR>", {
    desc = "Used to go to the location in the PDF from the code"
})

g.vimtex_view_method = 'skim'
g.vimtex_quickfix_open_on_warning = 0
